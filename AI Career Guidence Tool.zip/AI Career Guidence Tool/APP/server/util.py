import json
import pickle
import numpy as np

__data_columns = None
__model = None
__interested_subject = None


def get_predict_career(os, algo, se, pro_con, c_net, e_sub, c_arc, math,
                       c_skills, hours_work, cod_skill, pub_skill, read_write,
                       mem_skill, int_sub):
    careers = ['Database Developer', 'Portal Administrator',
               'Systems Security Administrator', 'Business Systems Analyst',
               'Software Systems Engineer', 'Business Intelligence Analyst',
               'CRM Technical Developer', 'Mobile Applications Developer',
               'UX Designer', 'Quality Assurance Associate', 'Web Developer',
               'Information Security Analyst', 'CRM Business Analyst',
               'Technical Support', 'Project Manager',
               'Information Technology Manager', 'Programmer Analyst',
               'Design & UX', 'Solutions Architect', 'Systems Analyst',
               'Network Security Administrator', 'Data Architect',
               'Software Developer', 'E-Commerce Analyst',
               'Technical Services/Help Desk/Tech Support',
               'Information Technology Auditor', 'Database Manager',
               'Applications Developer', 'Database Administrator',
               'Network Engineer', 'Software Engineer', 'Technical Engineer',
               'Network Security Engineer',
               'Software Quality Assurance (QA) / Testing']
    try:
        sub_index = __data_columns.index(int_sub.lower())
    except:
        sub_index = -1

    x = np.zeros(len(__data_columns))
    x[0] = os
    x[1] = algo
    x[2] = pro_con
    x[3] = se
    x[4] = c_net
    x[5] = e_sub
    x[6] = c_arc
    x[7] = math
    x[8] = c_skills
    x[9] = hours_work
    x[10] = cod_skill
    x[11] = pub_skill
    x[12] = read_write
    x[13] = mem_skill
    if sub_index >= 0:
        x[sub_index] = 1
    idx = __model.predict([x])
    return careers[idx[0]]


def load_saved_artifacts():
    print("loading saved artifacts....start")
    global __data_columns
    global __model
    global __interested_subject

    with open("./artifacts/columns.json", 'r') as f:
        __data_columns = json.load(f)['data_columns']
        __interested_subject = __data_columns[14:]

    with open("./artifacts/career_prediction.pickle", 'rb') as f:
        __model = pickle.load(f)
    print("loading saved artifacts.....Done")


if __name__ == "__main__":
    load_saved_artifacts()
    print(get_predict_career(70.0, 32.0, 6.0, 0.0, 52.0, 76.0, 64.0, 50.0, 44.0, 0.0, 5.0, 1.0, 0.0, 1.0,
                             "Computer Architecture"))
    print(get_predict_career(32.0, 5.0, 41.0, 14.0, 18.0, 70.0, 32.0, 97.0, 23.0, 25.0, 7.0, 3.0, 0.0, 1.0,
                             "networks"))
