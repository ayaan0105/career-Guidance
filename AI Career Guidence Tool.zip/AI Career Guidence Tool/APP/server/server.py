from flask import Flask, request, jsonify, render_template
import util

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict_career', methods=['POST'])
def predict_career():
    os = float(request.form['os'])
    algo = float(request.form['algo'])
    se = float(request.form['se'])
    pro_con = float(request.form['pro_con'])
    c_net = float(request.form['c_net'])
    e_sub = float(request.form['e_sub'])
    c_arc = float(request.form['c_arc'])
    math = float(request.form['math'])
    c_skills = float(request.form['c_skills'])
    hours_work = float(request.form['hours_work'])
    cod_skill = int(request.form['cod_skill'])
    pub_skill = int(request.form['pub_skill'])
    read_write = int(request.form['read_write'])
    mem_skill = int(request.form['mem_skill'])
    int_sub = request.form['int_sub']

    response = jsonify({
        'predicted_career': util.get_predict_career(os, algo, se, pro_con, c_net, e_sub, c_arc, math,
                                                    c_skills, hours_work, cod_skill, pub_skill, read_write,
                                                    mem_skill, int_sub)
    })
    response.headers.add('Access-Control-Allow-Origin', '*')
    return response


if __name__ == "__main__":
    app.run(debug=True)
